package com.mindtree.uistore;

import org.openqa.selenium.By;

public class automatingsearchpageui {
	public static By ourbrands =By.xpath("(//a[@class='m-nav-link m-list-item l-padding-left-none l-padding-right-none l-padding-bottom l-padding-top'])[4]");
	public static By destination=By.xpath("//input[@data-target='destination']");
	public static By search=By.xpath("//*[@id=\'find-a-hotel-homePage-form\']/div[2]/div[6]/button");
	public static By firstHotel=By.cssSelector(".l-s-col-4.l-m-col-8.l-l-col-12.l-m-col-last.l-s-col-last.t-font-s.t-line-height-m.m-hotel-address.t-color-standard-90");
	
	
}
